/**
 * 
 */
package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;
import java.util.Stack;
import java.util.Set;
import java.util.Collections;
import java.util.LinkedHashSet;

import graph.CapEdge;
import graph.CapNode;

import util.GraphLoader;

/**
 * @author Thomas Hepner
 * 
 * For the warm up assignment, you must implement your Graph in a class
 * named CapGraph.  Here is the stub file.
 *
 */
public class CapGraph implements Graph {
	private int numNodes;
	private int numEdges;
	private Map<Integer, CapNode> map;
	private Map<Integer, CapNode> mapTranspose;
	
	public CapGraph()
	{
		numNodes = 0;
		numEdges = 0;
		map = new HashMap<Integer, CapNode>();
		mapTranspose = new HashMap<Integer, CapNode>();
	}
	
	public int getNumNodes() {
		return numNodes;
	}
	
	
	public int getNumEdges() {
		return numEdges;
	}
	
	/* (non-Javadoc)
	 * @see graph.Graph#addVertex(int)
	 */
	@Override
	public void addVertex(int num) {
		if(!map.keySet().contains(num)) {
			CapNode node = new CapNode(num);
			numNodes += 1;
			map.put(num, node);
		}
	}

	/* (non-Javadoc)
	 * @see graph.Graph#addEdge(int, int)
	 */
	@Override
	public void addEdge(int from, int to) throws IndexOutOfBoundsException {
		if(map.keySet().contains(from) && map.keySet().contains(to)) {
			CapEdge edge = new CapEdge(from, to);
			numEdges += 1;
			CapNode node = map.get(from);
			node.addEdge(edge);
		} 
		else {
			throw new IndexOutOfBoundsException("Input integers do not exist as nodes in graph!"); 
		}
	}

	/* (non-Javadoc)
	 * @see graph.Graph#getEgonet(int)
	 */
	@Override
	public Graph getEgonet(int center) {
		Graph Egonet = new CapGraph();
		Egonet.addVertex(center);
		HashSet<CapEdge> centerEdges = map.get(center).getEdges();		
		Iterator<CapEdge> iterator = centerEdges.iterator();

		// Map center node and connect to adjacent nodes
		for(CapEdge nextEdge : centerEdges) {
			Egonet.addVertex(nextEdge.getEndNode());
			Egonet.addEdge(center,  nextEdge.getEndNode());
		}		
		
		// Map edges between non-central nodes
		while(iterator.hasNext()) {
			CapEdge nextEdge = iterator.next();
			Egonet.addEdge(nextEdge.getEndNode(), center);
			
			// Find adjacent edges to the current node
			HashSet<Integer> adjEdges = new HashSet<Integer>();
			for(CapEdge j : map.get(nextEdge.getEndNode()).getEdges()) {
				adjEdges.add(j.getEndNode());
			}
			
			// Connect adjacent edges where appropriate
			for(CapEdge edge : centerEdges) {				
				if(adjEdges.contains(edge.getEndNode())) {
					Egonet.addVertex(edge.getEndNode());
					Egonet.addEdge(nextEdge.getEndNode(), edge.getEndNode());
				}
			}	
		}
		return Egonet;
	}
	
	/* (non-Javadoc)
	 * @see graph.Graph#getSCCs()
	 */
	@Override
	public List<Graph> getSCCs() {
		List<Graph> SCCs = null;
		
		// Create stack of vertices in graph, smallest integer value should be at top of stack
		List<Integer> verticesList = new ArrayList(map.keySet());
		Collections.sort(verticesList, Collections.reverseOrder());
		Stack<Integer> vertices = new Stack<Integer>();	
		for(Integer vertex : verticesList) {
			vertices.push(vertex);
		}	
		
		// Visit all nodes in the graph and keep track of order of exploration				
		Stack<Integer> finished = DFS(map, vertices, null);	
		
		// Compute transpose of Graph
		CapGraph graphTranspose = transposeGraph(map);
		mapTranspose = graphTranspose.map;

		// Visit all nodes in the graph in reverse order
		SCCs = new ArrayList<Graph>();
		Stack<Integer> finishedTranspose = DFS(mapTranspose, finished, SCCs);	
		return SCCs;
	}
	
	
	// Reverses edges in CapGraph
	private CapGraph transposeGraph(Map<Integer, CapNode> map) {
		CapGraph GraphTranspose = new CapGraph();
		HashSet<CapNode> vertices = new HashSet<CapNode>();
		for(Integer vertex : map.keySet()) {
			vertices.add(map.get(vertex));
		}

		for(CapNode vertex : vertices) {
			HashSet<CapEdge> edges = vertex.getEdges();	
			GraphTranspose.addVertex(vertex.getNode());
			for(CapEdge edge : edges) {
				GraphTranspose.addVertex(edge.getEndNode());
				GraphTranspose.addEdge(edge.getEndNode(), vertex.getNode());
			}
		}
		return GraphTranspose;
	}

	
	// Depth First Search Algorithm: Iterates over all nodes in the graph
	private Stack<Integer> DFS(Map<Integer, CapNode> map, Stack<Integer> vertices, List<Graph> SCCs) { 
		
		HashSet<Integer> visited = new HashSet<Integer>(); 
		Stack<Integer> finished = new Stack<Integer>(); 
		
		while(!vertices.isEmpty()) {
			Integer v = vertices.pop();
			CapGraph subgraph = new CapGraph();		
			HashSet<CapEdge> edges = map.get(v).getEdges();

			if(!visited.contains(v)) {
				subgraph.addVertex(v);
				subgraph = DFS_VISIT(map, v, visited, finished, subgraph);
			}
			
			if(SCCs != null & subgraph.getNumNodes() > 0) {
				SCCs.add(subgraph);
			}
		}
		return finished;
	}
	
	// Visits node if it hasn't been visited yet
	private CapGraph DFS_VISIT(Map<Integer, CapNode> map, Integer v, HashSet<Integer> visited, Stack<Integer> finished, CapGraph subgraph) {
		visited.add(v);
		
		HashSet<CapEdge> edges = map.get(v).getEdges();
		for(CapEdge edge : edges) { // v.getEdges
			Integer n = edge.getEndNode();
			if(!visited.contains(n)) {
				subgraph.addVertex(n);
				subgraph.addEdge(v, n);
				DFS_VISIT(map, n, visited, finished, subgraph);
			}
		}
		finished.push(v);
		return subgraph;
	}
	
	/* (non-Javadoc)
	 * @see graph.Graph#exportGraph()
	 */
	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		HashMap<Integer, HashSet<Integer>> export = new HashMap<Integer, HashSet<Integer>>();
		for(Integer key : map.keySet()) {
			HashSet<CapEdge> edges = map.get(key).getEdges();
			HashSet<Integer> adjEdges = new HashSet<Integer>();
			for(CapEdge j : edges) {
				adjEdges.add(j.getEndNode());
			}
			export.put(key, adjEdges);
		}		
		return export;
	}
	
	public static void main(String[] args)
	{		
		// Use this code to test results
		CapGraph theMap = new CapGraph();
		System.out.print("DONE. \nLoading the map..."); 
		GraphLoader.loadGraph(theMap, "data/scc/test_special.txt"); // test_special |  test_1
		System.out.println("DONE.");	
		
		// Store map in different format for grading purposes
		/*
		HashMap<Integer, HashSet<Integer>> exportMap = theMap.exportGraph();
		for(Integer key : exportMap.keySet()) {
			System.out.println("Node: " + key + " , Edges: " + exportMap.get(key));
		}
		*/
		
		// Test EgoNet
		/*
		Graph ego = theMap.getEgonet(22);
		HashMap<Integer, HashSet<Integer>> exportEgo = ego.exportGraph();
		for(Integer key : exportEgo.keySet()) {
			System.out.println("Node: " + key + " , Edges: " + exportEgo.get(key));
		}
		*/
		
		// Test getSCCs
		List<Graph> SCCs = theMap.getSCCs();
		System.out.println("Strongly Connected Components: ");
		for(Graph SCC : SCCs) {
			HashMap<Integer, HashSet<Integer>> exportNextSCC = SCC.exportGraph();
			Set<Integer> graphNodes = exportNextSCC.keySet();
			// System.out.print(graphNodes + " : ");
			for(Integer node : graphNodes) {
				System.out.print(node + " ");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("Size: " + SCCs.size());
		
		
	}

}
